using System;

namespace Astrila.HiveNet
{
	/// <summary>
	/// Summary description for PeerEndPoint.
	/// </summary>
	public class PeerEndPoint
	{
		public bool IsOnline()
		{
			throw new NotImplementedException();
		}

		public PeerNetworkAddress Address
		{
			get
			{
				throw new NotImplementedException();
			}
		}
	}
}
