using System;
using System.Collections;
using System.Diagnostics;

namespace Astrila.HiveNet
{
	public enum PolygoneEndType
	{
		N=0, S=1, NE=2, SE=3, NW=4, SW=5, Uninitialized=6
	}

	[Flags()]
	public enum RoutingModeType
	{
		Connect = 1,
		RouteOnlyIfExactMatch = 2,
		RouteOnlyOnRandomEdge = 4,
		Route = RouteOnlyIfExactMatch | RouteOnlyOnRandomEdge,
		ConnectOrRoute = Connect | Route,
		ConnectOrRouteOnlyIfExactMatch = Connect | RouteOnlyIfExactMatch,
		None = 0
	}

	public class PolygoneEdge
	{
		public const int UNCONSTRUCTED_POLYGONE_ID = 0;

		public PolygoneEndType EndType = PolygoneEndType.Uninitialized;

		public PolygoneNode ConnectedNode = null;

		public int LeftPolygoneID = UNCONSTRUCTED_POLYGONE_ID;
		public int RightPolygoneID = UNCONSTRUCTED_POLYGONE_ID;
		public int OppositePolygoneID = UNCONSTRUCTED_POLYGONE_ID;

		public PolygoneEdge LeftEdge = null;
		public PolygoneEdge RightEdge = null;


		internal void CopyEndTypeFrom(PolygoneEdge anotherEdge)
		{
			EndType = anotherEdge.EndType;
		}

		public bool IsConnected
		{
			get
			{
				return ConnectedNode != null;	
			}
		}

		private bool IsLeftPolygoneSymmytric(PolygoneEdge anotherEdge)
		{
			return ((LeftPolygoneID == anotherEdge.RightPolygoneID) || (LeftPolygoneID == 0) || (anotherEdge.RightPolygoneID == 0))
				&& ((LeftPolygoneID != anotherEdge.OppositePolygoneID) || (LeftPolygoneID == 0) || (anotherEdge.OppositePolygoneID == 0));
		}
		private bool IsRightPolygoneSymmytric(PolygoneEdge anotherEdge)
		{
			return ((RightPolygoneID == anotherEdge.LeftPolygoneID) || (RightPolygoneID == 0) || (anotherEdge.LeftPolygoneID == 0))
				&& ((RightPolygoneID != anotherEdge.OppositePolygoneID) || (RightPolygoneID == 0) || (anotherEdge.OppositePolygoneID == 0));
		}
		private bool IsSymmystricToEdge(PolygoneEdge anotherEdge)
		{
			return IsLeftPolygoneSymmytric(anotherEdge) && IsRightPolygoneSymmytric(anotherEdge);
		}
		private bool IsOppositeToEdge(PolygoneEdge anotherEdge)
		{
			return ((OppositePolygoneID != anotherEdge.OppositePolygoneID) || (anotherEdge.OppositePolygoneID == 0) || (OppositePolygoneID == 0))
				&& ((OppositePolygoneID != anotherEdge.RightPolygoneID) || (OppositePolygoneID == 0) || (anotherEdge.RightPolygoneID == 0))
				&& ((OppositePolygoneID != anotherEdge.LeftPolygoneID) || (OppositePolygoneID == 0) || (anotherEdge.LeftPolygoneID == 0));
		}

		private bool IsEndTypeCompatible(PolygoneEdge anotherEdge)
		{
			return ((EndType == GeometricUtils.GetOppositeEndType(anotherEdge.EndType)) || (EndType == PolygoneEndType.Uninitialized)  || (anotherEdge.EndType == PolygoneEndType.Uninitialized));
		}
		public bool IsCompatibleToEdge(PolygoneEdge anotherEdge)
		{
			return IsSymmystricToEdge(anotherEdge) && IsOppositeToEdge(anotherEdge) && IsEndTypeCompatible(anotherEdge)
				&& LeftEdge.IsEndTypeCompatible(anotherEdge.LeftEdge) && RightEdge.IsEndTypeCompatible(anotherEdge.RightEdge);
		}

		public bool IsRoutableToEdge(PolygoneEdge anotherEdge)
		{
			return IsLeftPolygonesExactlyEqual(anotherEdge) || IsRightPolygonesExactlyEqual(anotherEdge);
		}

		
		private void FuseEndTypes(PolygoneEdge otherNodeEdge, PolygoneEndType defaultEndType)
		{
			if (EndType == PolygoneEndType.Uninitialized)
			{
				if (otherNodeEdge.EndType != PolygoneEndType.Uninitialized)
					EndType = GeometricUtils.GetOppositeEndType(otherNodeEdge.EndType);
				else
					EndType = defaultEndType;
			}
			//else other edge should pick up my type

			LeftEdge.EndType = GeometricUtils.GetLeftEndType(EndType);
			RightEdge.EndType = GeometricUtils.GetRightEndType(EndType);
		}

		internal int[] backupEdges = null;
		private void FusePolygones(PolygoneEdge otherNodeEdge, int defaultLeftPolygoneID, int defaultRightPolygoneID)
		{
			backupEdges = new int[] {LeftPolygoneID, RightPolygoneID, OppositePolygoneID};
			if (LeftPolygoneID == UNCONSTRUCTED_POLYGONE_ID)
			{
				if (otherNodeEdge.RightPolygoneID != UNCONSTRUCTED_POLYGONE_ID)
					LeftPolygoneID = otherNodeEdge.RightPolygoneID;
				else
					LeftPolygoneID = defaultLeftPolygoneID;
			}
			LeftEdge.RightPolygoneID = LeftPolygoneID;
			RightEdge.OppositePolygoneID = LeftPolygoneID;

			if (RightPolygoneID == UNCONSTRUCTED_POLYGONE_ID)
			{
				if (otherNodeEdge.LeftPolygoneID != UNCONSTRUCTED_POLYGONE_ID)
					RightPolygoneID = otherNodeEdge.LeftPolygoneID;
				else
					RightPolygoneID = defaultRightPolygoneID;
			}
			RightEdge.LeftPolygoneID = RightPolygoneID;
			LeftEdge.OppositePolygoneID = RightPolygoneID;
			Debug.Assert((RightPolygoneID != LeftPolygoneID) && (RightPolygoneID != OppositePolygoneID) && (LeftPolygoneID != OppositePolygoneID), "same adjescent polygones found");
		}

		internal void FuseEdges(PolygoneEdge otherNodeEdge, PolygoneNode otherNode, int defaultLeftPolygoneID, int defaultRightPolygoneID, PolygoneEndType defaultEdgeType)
		{
			FuseEndTypes(otherNodeEdge, defaultEdgeType);
			FusePolygones(otherNodeEdge, defaultLeftPolygoneID, defaultRightPolygoneID);
			ConnectedNode = otherNode;
		}

		public bool IsLeftPolygonesExactlyEqual(PolygoneEdge anotherEdge)
		{
			return (LeftPolygoneID == anotherEdge.RightPolygoneID) && (LeftPolygoneID != UNCONSTRUCTED_POLYGONE_ID) && (anotherEdge.RightPolygoneID != UNCONSTRUCTED_POLYGONE_ID);
		}
		public bool IsRightPolygonesExactlyEqual(PolygoneEdge anotherEdge)
		{
			return (RightPolygoneID == anotherEdge.LeftPolygoneID) && (RightPolygoneID != UNCONSTRUCTED_POLYGONE_ID) && (anotherEdge.LeftPolygoneID != UNCONSTRUCTED_POLYGONE_ID);
		}
		public bool IsEndTypeExactlyOppositeTo(PolygoneEdge anotherEdge)
		{
			return (EndType == GeometricUtils.GetOppositeEndType(anotherEdge.EndType)) && (EndType != PolygoneEndType.Uninitialized) && (anotherEdge.EndType != PolygoneEndType.Uninitialized);
		}

		public bool IsSameTypeAs(PolygoneEdge anotherEdge)
		{
			if (anotherEdge != null)
				return IsEndTypeExactlyOppositeTo(anotherEdge) || (EndType == anotherEdge.EndType);
			else
				return false;
		}
	}

	public class PolygoneEdgePair
	{
		public PolygoneEdge Edge1 = null;
		public PolygoneEdge Edge2 = null;
		public PolygoneEdgePair(PolygoneEdge paramEdge1, PolygoneEdge paramEdge2)
		{
			Edge1 = paramEdge1;
			Edge2 = paramEdge2;
		}
	}

	internal class NetworkSettings
	{
		static public int HyperNodeCapabilityFrequency = 18;	//One out of every 18 nodes can become a hypernode
		static public int StartingEdgeChangeFrequency = 12;
		static public int MaxReboundHopCount = 0;
		static public bool EnableHyperNetRouting = false;
		static public int MaxNodeHopCount =(EnableHyperNetRouting)?1000:int.MaxValue;
		static public int NodeHopThresoldForHyperNodeCreation = 24;	//Request should have been hopped atleast this many times to trigger hyper node creation for the original entry
	}

	public class PolygoneNode
	{
		public PolygoneEdge[] Edges = null;
		public string ID = Guid.NewGuid().ToString();
		public string NetworkID = null;

		protected PolygoneNode ParentNetNode = null;
		public PolygoneNode HyperNetNode = null;

		private int _ConnectRequestCount = 0;
		private int ConnectRequestCount
		{
			get
			{
				return _ConnectRequestCount;
			}
			set
			{
				_ConnectRequestCount=value;
			}
		}

		public PolygoneNode()
		{
			ConstructorCommon(null);
		}

		private void ConstructorCommon(PolygoneNode paramParentNetNode)
		{
			IsHyperNodeCapable = (GeometricUtils.GetRandomNumber(0, NetworkSettings.HyperNodeCapabilityFrequency-1)==0);
			ResetStateToUnconnectedNode((paramParentNetNode!=null)?paramParentNetNode.Edges:null);	
			ParentNetNode = paramParentNetNode;
			OnAfterCreated();
		}

		private PolygoneNode(PolygoneNode paramParentNetNode)
		{
			ConstructorCommon(paramParentNetNode);
		}

		protected virtual void OnHyperNodeCreated()
		{
			
		}

		public PolygoneNode GetOrCreateHyperNode()
		{
			if (HyperNetNode == null)
			{
				HyperNetNode = new PolygoneNode(this);
				OnHyperNodeCreated();
			}
			return HyperNetNode;
		}

		public bool IsHyperNetNodeConnected
		{
			get
			{
				return (HyperNetNode != null) && (HyperNetNode.IsConnected);				
			}
		}

		public void ResetStateToUnconnectedNode(PolygoneEdge[] copyEndTypesFrom)
		{
			Edges = new PolygoneEdge[] {new PolygoneEdge() , new PolygoneEdge() , new PolygoneEdge()};
			Edges[0].LeftEdge = Edges[1];
			Edges[0].RightEdge = Edges[2];
			Edges[1].LeftEdge = Edges[2];
			Edges[1].RightEdge = Edges[0];
			Edges[2].LeftEdge = Edges[0];
			Edges[2].RightEdge = Edges[1];

			if (copyEndTypesFrom != null)
			{
				Edges[0].CopyEndTypeFrom(copyEndTypesFrom[0]);
				Edges[1].CopyEndTypeFrom(copyEndTypesFrom[1]);
				Edges[2].CopyEndTypeFrom(copyEndTypesFrom[2]);
			}
		}

		public PolygoneEdgePair[] GetConnectableEdgePairs(PolygoneNode anotherNode)
		{
			ArrayList connectableEdgesList = new ArrayList(3);
			for (int myEdgeIndex = 0; myEdgeIndex < 3; myEdgeIndex++)
			{
				for (int anotherNodeEdgeIndex = 0; anotherNodeEdgeIndex < 3; anotherNodeEdgeIndex++)
				{
					if (!Edges[myEdgeIndex].IsConnected && !anotherNode.Edges[anotherNodeEdgeIndex].IsConnected && Edges[myEdgeIndex].IsCompatibleToEdge(anotherNode.Edges[anotherNodeEdgeIndex]))
					{
						connectableEdgesList.Add(new PolygoneEdgePair(Edges[myEdgeIndex], anotherNode.Edges[anotherNodeEdgeIndex]));
					}
				}
			}

			return (PolygoneEdgePair[]) connectableEdgesList.ToArray(typeof(PolygoneEdgePair));
		}


		public void CreateConnection(PolygoneEdge myNodeEdge, PolygoneEdge otherNodeEdge, PolygoneNode otherNode, int defaultLeftPolygoneID, int defaultRightPolygoneID, PolygoneEndType defaultEdgeType)
		{
			if (NetworkID == null)
				NetworkID = otherNode.NetworkID;
			else if (!IsCompatibleNetwork(otherNode.NetworkID))
				throw new Exception("Attempt to connect nodes of different networks");

			myNodeEdge.FuseEdges(otherNodeEdge, otherNode, defaultLeftPolygoneID, defaultRightPolygoneID, defaultEdgeType);
		}

		private PolygoneEdge[] GetRoutableEdges(PolygoneNode anotherNode, PolygoneEdge excludedEdge)
		{
			ArrayList routableEdgesList = new ArrayList(3);
			for (int myEdgeIndex = 0; myEdgeIndex < 3; myEdgeIndex++)
			{
				if (!Edges[myEdgeIndex].IsSameTypeAs(excludedEdge))
				{
					for (int anotherNodeEdgeIndex = 0; anotherNodeEdgeIndex < 3; anotherNodeEdgeIndex++)
					{
						if (Edges[myEdgeIndex].IsConnected && !anotherNode.Edges[anotherNodeEdgeIndex].IsConnected && Edges[myEdgeIndex].IsRoutableToEdge(anotherNode.Edges[anotherNodeEdgeIndex]))
						{
							routableEdgesList.Add(Edges[myEdgeIndex]);
							break;
						}
					}
				}
			}

			return (PolygoneEdge[]) routableEdgesList.ToArray(typeof(PolygoneEdge));
		}

		public PolygoneEdge[] GetAllConnectedEdges(PolygoneEdge excludedEdgeType, PolygoneEdge onlyIncludeEdgeType, PolygoneEndType[] excludeExactEdgeTypes)
		{
			ArrayList connectedEdgesList = new ArrayList(3);
			for (int myEdgeIndex = 0; myEdgeIndex < 3; myEdgeIndex++)
			{
				if (Edges[myEdgeIndex].IsConnected 
					&& (!Edges[myEdgeIndex].IsSameTypeAs(excludedEdgeType) || (excludedEdgeType == null))
					&& (Edges[myEdgeIndex].IsSameTypeAs(onlyIncludeEdgeType) || (onlyIncludeEdgeType == null)))
				{
					bool excludeThisEdge = false;
					if (excludeExactEdgeTypes != null)
					{
						for (int excludeExactEdgeTypeIndex=0; excludeExactEdgeTypeIndex < excludeExactEdgeTypes.Length; excludeExactEdgeTypeIndex++)
						{
							if (Edges[myEdgeIndex].EndType == excludeExactEdgeTypes[excludeExactEdgeTypeIndex])
							{
								excludeThisEdge = true;
								break;
							}
						}
					}
					if (!excludeThisEdge)
						connectedEdgesList.Add(Edges[myEdgeIndex]);
				}
			}

			return (PolygoneEdge[]) connectedEdgesList.ToArray(typeof(PolygoneEdge));			
		}

		protected virtual void OnAfterCreated() {}
		protected virtual void OnConnectionCompleted(PolygoneNode otherNode, PolygoneEdge otherNodeEdge, PolygoneEdge myEdge)
		{}

		protected virtual void OnBeforeConnectToIncomingNode(PolygoneNode incomingNode, RoutingInfo paramRoutingInfo)
		{}

		protected virtual void OnAfterConnectToIncomingNode(PolygoneNode incomingNode, RoutingInfo paramRoutingInfo)
		{}


		public void NotifyConnectionSucceded(PolygoneNode otherNode, PolygoneEdge otherNodeEdge, PolygoneEdge myEdge, RoutingInfo paramRoutingInfo)
		{
			//TODO: this code should be also executed if node hops gets exuasted
			//If we had to travel too far, we should ask entry node to create hypernet
			if ((paramRoutingInfo.HyperNetEntryNode == null) && (paramRoutingInfo.NodeHopsCount > NetworkSettings.NodeHopThresoldForHyperNodeCreation))
			{
				paramRoutingInfo.OriginalEntryNode.RequestHyperNetCreation();
			}

			OnConnectionCompleted(otherNode, otherNodeEdge, myEdge);			
		}

		public void RequestConnectToNetwork(PolygoneNode incomingNode)
		{
			RequestConnectToNetwork(incomingNode, new RoutingInfo(this));
		}


		public void RequestHyperNetCreation()
		{
			GetOrCreateHyperNode();
		}

		private string _Logs = "";
		private void LogMessage(string message)
		{
			_Logs += message;
			if (_Logs.Length > 1000) _Logs=_Logs.Substring(_Logs.Length - 1000);
		}

		public bool IsConnected
		{
			get
			{
				return NetworkID != null;
			}
		}


		private bool IsCompatibleNetwork(string otherNetworkID)
		{
			return (NetworkID == otherNetworkID) || (NetworkID == null) || (otherNetworkID == null);
		}


		protected virtual void OnHyperNodeParticipationChange()
		{
			
		}

		internal virtual void NotifyHyperNodeParticipationChange()
		{
			OnHyperNodeParticipationChange();
			if (ParentNetNode != null) ParentNetNode.NotifyHyperNodeParticipationChange();
		}

		public bool IsHyperNodeCapable = false;

		private void HyperNetParticipation(RoutingInfo paramRoutingInfo)
		{
			//TODO: stitch algorithm for hypernode is needed here
			if ((IsHyperNetNodeConnected == false) && (paramRoutingInfo.HyperNetEntryNode != null) && (IsHyperNodeCapable))
			{
				//Lets participate in the hypernet
				PolygoneNode myHyperNode = GetOrCreateHyperNode();
				paramRoutingInfo.HyperNetEntryNode.RequestConnectToNetwork(myHyperNode, new RoutingInfo(null, paramRoutingInfo.HyperNetEntryNode, null, null, null, RoutingModeType.ConnectOrRoute, NoRoutingActionType.None, NetworkSettings.MaxReboundHopCount-3, 0, null));
				NotifyHyperNodeParticipationChange();
			}
		}

		private bool ValidateConnectRequest(PolygoneNode incomingNode, RoutingInfo paramRoutingInfo)
		{
			bool isValidRequest = false;
			if (((paramRoutingInfo.RoutingMode & RoutingModeType.Connect)!=RoutingModeType.None))
			{
				isValidRequest = IsCompatibleNetwork(incomingNode.NetworkID);	
				if (!isValidRequest)
					incomingNode.NotifyIncompatibleNetwork(this);
			}
			else
			{
				isValidRequest = true;				
			}
			
			return isValidRequest;
		}

		public void RequestConnectToNetwork(PolygoneNode incomingNode, RoutingInfo paramRoutingInfo)
		{
			OnBeforeConnectToIncomingNode(incomingNode, paramRoutingInfo);
			if (incomingNode != this)
			{
				ConnectRequestCount++;
				if (ValidateConnectRequest(incomingNode, paramRoutingInfo))
				{
					HyperNetParticipation(paramRoutingInfo);
					bool isNodeRoutedOrConnected = false;
					if ((!isNodeRoutedOrConnected) && ((paramRoutingInfo.RoutingMode & RoutingModeType.Connect) != RoutingModeType.None))
					{
						isNodeRoutedOrConnected = TryConnectingToIncomingNode(incomingNode, paramRoutingInfo);
					}

					if ((!isNodeRoutedOrConnected) && ((paramRoutingInfo.RoutingMode & RoutingModeType.Route) != RoutingModeType.None))
					{
						isNodeRoutedOrConnected = TryRoutingIncomingNode(incomingNode, paramRoutingInfo);
					}

					if (!isNodeRoutedOrConnected)
					{
						TryRouteToParentOrReboundingIncomingNode(incomingNode, paramRoutingInfo);
					}
				}
				//else incomingNode would be notified of invalid request
			}
			else
			{
				//Debug.Assert(false, "Self connect request found");				
			}

			OnAfterConnectToIncomingNode(incomingNode, paramRoutingInfo);
		}

		private bool TryRoutingIncomingNode(PolygoneNode incomingNode, RoutingInfo paramRoutingInfo)
		{
			bool isNodeRoutedOrConnected = false;
			if (paramRoutingInfo.NodeHopsCount <= NetworkSettings.MaxNodeHopCount)
			{
				if ((paramRoutingInfo.RoutingMode & RoutingModeType.RouteOnlyIfExactMatch) != RoutingModeType.None)
				{
					isNodeRoutedOrConnected = RouteIncomingNodeAroundPolygone(incomingNode, paramRoutingInfo);
				}
	
				if ((paramRoutingInfo.RoutingMode & RoutingModeType.RouteOnlyOnRandomEdge) != RoutingModeType.None)
				{
					isNodeRoutedOrConnected = RouteIncomingNodeToRandomEdge(incomingNode, paramRoutingInfo);
				}
			}
			else
			{
				if ((paramRoutingInfo.NoRoutingAction & NoRoutingActionType.Acknowledge)!=NoRoutingActionType.None)
					incomingNode.NotifyNodeHopsExausted(this, paramRoutingInfo);
			}

			return isNodeRoutedOrConnected;
		}


		public void NotifyNodeHopsExausted(PolygoneNode fromNode, RoutingInfo paramRoutingInfo)
		{
			throw new Exception("Node hops has been exausted");
		}

		private void TryRouteToParentOrReboundingIncomingNode(PolygoneNode incomingNode, RoutingInfo paramRoutingInfo)
		{
			if (paramRoutingInfo.ReboundHopsCount >= NetworkSettings.MaxReboundHopCount)
			{
				if (((paramRoutingInfo.NoRoutingAction & NoRoutingActionType.RouteToParent)!=NoRoutingActionType.None)
					&& (ParentNetNode != null))
				{
					//Drop out of hypernet
					RoutingInfo parentRoutingInfo = paramRoutingInfo.ParentRoutingInfo;
					ParentNetNode.RequestConnectToNetwork(incomingNode, new RoutingInfo(parentRoutingInfo.ParentRoutingInfo,  parentRoutingInfo.OriginalEntryNode, paramRoutingInfo.RequestOriginalyStartedOnEdge, paramRoutingInfo.RequestLastStartedOnEdge,  paramRoutingInfo.RequestLastArrivedOnEdge,  parentRoutingInfo.RoutingMode, parentRoutingInfo.NoRoutingAction,  parentRoutingInfo.ReboundHopsCount,  paramRoutingInfo.NodeHopsCount,  this));
				}
				else
				{
					if ((paramRoutingInfo.NoRoutingAction & NoRoutingActionType.Acknowledge)!=NoRoutingActionType.None)
						incomingNode.NoRoutingAvailable(this, paramRoutingInfo);
				}
			}
			else
			{
				//lets rebound this node back in to the network for routing
				//Note: we are not resetting node hop counter
				TryRoutingIncomingNode(incomingNode, new RoutingInfo(paramRoutingInfo.ParentRoutingInfo, paramRoutingInfo.OriginalEntryNode, null, null, null, paramRoutingInfo.RoutingMode, paramRoutingInfo.NoRoutingAction, paramRoutingInfo.ReboundHopsCount+1, 0, GetHyperNetEntryNode(paramRoutingInfo)));
			}
		}

		private PolygoneNode GetHyperNetEntryNode(RoutingInfo paramRoutingInfo)
		{
			if (paramRoutingInfo.HyperNetEntryNode != null)
				return paramRoutingInfo.HyperNetEntryNode;
			else
				return HyperNetNode;
		}

		public bool IsHyperNodeFullyConnected
		{
			get
			{
				return (HyperNetNode != null) && (HyperNetNode.Edges[0].IsConnected)  && (HyperNetNode.Edges[1].IsConnected)  && (HyperNetNode.Edges[2].IsConnected);				
			}
		}

		private bool RouteIncomingNodeToRandomEdge(PolygoneNode incomingNode, RoutingInfo paramRoutingInfo)
		{
			bool isNodeRouted = false;

			if ((IsHyperNodeFullyConnected == false)||(!NetworkSettings.EnableHyperNetRouting))
			{
				PolygoneEdge[] routableEdges;
				if (paramRoutingInfo.RequestLastStartedOnEdge == null)
				{
					routableEdges=GetAllConnectedEdges(paramRoutingInfo.RequestLastArrivedOnEdge, null, null);	//Get all edges	//new PolygoneEdge[]{ Edges[0]};
				}
				else
				{
					routableEdges= GetAllConnectedEdges(paramRoutingInfo.RequestLastArrivedOnEdge, null, GeometricUtils.GetToBeExcludedEndTypes(paramRoutingInfo.RequestLastStartedOnEdge.EndType));								
				}
		
				if(routableEdges.Length > 0)
				{
					PolygoneEdge choosenEdge = routableEdges[GeometricUtils.GetRandomNumber(0, routableEdges.Length-1)];
					PolygoneEdge startingEdge = null;
					if ((GeometricUtils.GetRandomNumber(0, NetworkSettings.StartingEdgeChangeFrequency-1)==0)
						&& (paramRoutingInfo.RequestOriginalyStartedOnEdge!=null) && (GeometricUtils.IsAdjescentEndTypes(paramRoutingInfo.RequestOriginalyStartedOnEdge.EndType, choosenEdge.EndType)))
					{
						//Switch to new starting edge startingEdge
						startingEdge = choosenEdge;
					}
					else
					{
						startingEdge = (paramRoutingInfo.RequestLastStartedOnEdge != null)?paramRoutingInfo.RequestLastStartedOnEdge:((paramRoutingInfo.RequestLastArrivedOnEdge!=null)?choosenEdge:((GeometricUtils.GetRandomNumber(0,1)==0)?choosenEdge:null));
					}
					PolygoneEdge originalStartingEdge = (paramRoutingInfo.RequestOriginalyStartedOnEdge!=null)?paramRoutingInfo.RequestOriginalyStartedOnEdge:startingEdge;
					choosenEdge.ConnectedNode.RequestConnectToNetwork(incomingNode, 
						new RoutingInfo(paramRoutingInfo.ParentRoutingInfo, paramRoutingInfo.OriginalEntryNode, originalStartingEdge, startingEdge, choosenEdge, paramRoutingInfo.RoutingMode, paramRoutingInfo.NoRoutingAction, paramRoutingInfo.ReboundHopsCount, paramRoutingInfo.NodeHopsCount+1, GetHyperNetEntryNode(paramRoutingInfo)));
					isNodeRouted=true;
				}
			}
			else
			{
				isNodeRouted=true;
				//Switch to hypernet routing
				HyperNetNode.RequestConnectToNetwork(incomingNode, 
					new RoutingInfo(paramRoutingInfo, HyperNetNode, paramRoutingInfo.RequestOriginalyStartedOnEdge,   paramRoutingInfo.RequestLastStartedOnEdge,  
						paramRoutingInfo.RequestLastArrivedOnEdge,  RoutingModeType.RouteOnlyOnRandomEdge, NoRoutingActionType.RouteToParentOrAcknowledge, 0, paramRoutingInfo.NodeHopsCount, HyperNetNode.HyperNetNode));
			}
			return isNodeRouted;
		}

		private bool RouteIncomingNodeAroundPolygone(PolygoneNode incomingNode, RoutingInfo paramRoutingInfo)
		{
			bool isNodeRouted = false;
			PolygoneEdge[] routableEdges = GetRoutableEdges(incomingNode, paramRoutingInfo.RequestLastArrivedOnEdge);
			if (routableEdges.Length > 0)
			{
				PolygoneEdge choosenEdge = routableEdges[GeometricUtils.GetRandomNumber(0, routableEdges.Length-1)];
				PolygoneEdge startingEdge = (paramRoutingInfo.RequestLastStartedOnEdge != null)?paramRoutingInfo.RequestLastStartedOnEdge:((paramRoutingInfo.RequestLastArrivedOnEdge!=null)?choosenEdge:((GeometricUtils.GetRandomNumber(0,1)==0)?choosenEdge:null));
				PolygoneEdge originalStartingEdge = (paramRoutingInfo.RequestOriginalyStartedOnEdge!=null)?paramRoutingInfo.RequestOriginalyStartedOnEdge:startingEdge;
				choosenEdge.ConnectedNode.RequestConnectToNetwork(incomingNode, new RoutingInfo(paramRoutingInfo.ParentRoutingInfo, paramRoutingInfo.OriginalEntryNode, originalStartingEdge, startingEdge, choosenEdge, paramRoutingInfo.RoutingMode, paramRoutingInfo.NoRoutingAction, paramRoutingInfo.ReboundHopsCount, paramRoutingInfo.NodeHopsCount+1, GetHyperNetEntryNode(paramRoutingInfo)));
				isNodeRouted=true;
			}
			return isNodeRouted;
		}

		private bool TryConnectingToIncomingNode(PolygoneNode incomingNode, RoutingInfo paramRoutingInfo)
		{
			bool isNodeRoutedOrConnected = false;

			PolygoneEdgePair[] PolygoneEdgePairs = GetConnectableEdgePairs(incomingNode);
			if (PolygoneEdgePairs.Length > 0)	//We have connectable edges
			{
				PolygoneEdgePair choosenPolygoneEdgePair = PolygoneEdgePairs[GeometricUtils.GetRandomNumber(0,PolygoneEdgePairs.Length-1)];
				
				int defaultLeftPolygoneID = GeometricUtils.GetNewPolygoneID();
				int defaultRightPolygoneID = GeometricUtils.GetNewPolygoneID();
				
				//TODO: Transaction should start here
				if (NetworkID==null) NetworkID = Guid.NewGuid().ToString();
				incomingNode.CreateConnection(choosenPolygoneEdgePair.Edge2, choosenPolygoneEdgePair.Edge1, this, defaultRightPolygoneID, defaultLeftPolygoneID, PolygoneEndType.S);
				this.CreateConnection(choosenPolygoneEdgePair.Edge1, choosenPolygoneEdgePair.Edge2, incomingNode, defaultLeftPolygoneID, defaultRightPolygoneID, PolygoneEndType.N);
		
				incomingNode.NotifyConnectionSucceded(this,choosenPolygoneEdgePair.Edge1, choosenPolygoneEdgePair.Edge2, paramRoutingInfo);
				OnConnectionCompleted(incomingNode, choosenPolygoneEdgePair.Edge2, choosenPolygoneEdgePair.Edge1);			
		
				//move the request around
				if (choosenPolygoneEdgePair.Edge1.LeftEdge.IsConnected)
					choosenPolygoneEdgePair.Edge1.LeftEdge.ConnectedNode.RequestConnectToNetwork(incomingNode, new RoutingInfo(null, this, choosenPolygoneEdgePair.Edge1.LeftEdge, choosenPolygoneEdgePair.Edge1.LeftEdge, choosenPolygoneEdgePair.Edge1.LeftEdge, RoutingModeType.ConnectOrRouteOnlyIfExactMatch, NoRoutingActionType.None, 0, NetworkSettings.MaxNodeHopCount-12, GetHyperNetEntryNode(paramRoutingInfo)));
				if (choosenPolygoneEdgePair.Edge1.RightEdge.IsConnected)
					choosenPolygoneEdgePair.Edge1.RightEdge.ConnectedNode.RequestConnectToNetwork(incomingNode, new RoutingInfo(null, this, choosenPolygoneEdgePair.Edge1.RightEdge, choosenPolygoneEdgePair.Edge1.RightEdge, choosenPolygoneEdgePair.Edge1.RightEdge, RoutingModeType.ConnectOrRouteOnlyIfExactMatch, NoRoutingActionType.None, 0, NetworkSettings.MaxNodeHopCount-12, GetHyperNetEntryNode(paramRoutingInfo)));
				isNodeRoutedOrConnected = true;
			}
			return isNodeRoutedOrConnected;
		}

		public void NotifyIncompatibleNetwork(PolygoneNode fromNode)
		{
			throw new Exception("Incompatible network found!");
		}

		public int GetHyperNetHeight()
		{
			int depth = 0;
			PolygoneNode nextNode=HyperNetNode;
			while (nextNode != null)
			{
				depth++;
				nextNode = nextNode.HyperNetNode;
			}
			return depth;
		}

		public void NoRoutingAvailable(PolygoneNode lastNode, RoutingInfo paramRoutingInfo)
		{
			throw new Exception("No routing available");
		}
	}

	[Flags]
	public enum NoRoutingActionType
	{
		Acknowledge = 1,
		None = 0,
		RouteToParent = 2,
		RouteToParentOrAcknowledge = Acknowledge | RouteToParent
	}

	public class RoutingInfo
	{
		public PolygoneEdge RequestOriginalyStartedOnEdge = null;
		public PolygoneEdge RequestLastStartedOnEdge = null;
		public PolygoneEdge RequestLastArrivedOnEdge = null;
		public RoutingModeType RoutingMode = RoutingModeType.ConnectOrRoute;
		public NoRoutingActionType NoRoutingAction = NoRoutingActionType.Acknowledge;
		public int ReboundHopsCount = 0;
		public int NodeHopsCount = 0;
		public PolygoneNode HyperNetEntryNode = null;
		public PolygoneNode OriginalEntryNode = null;
		public RoutingInfo ParentRoutingInfo = null;

		public RoutingInfo(PolygoneNode paramOriginalEntryNode)
		{
			OriginalEntryNode = paramOriginalEntryNode;
		}
		public RoutingInfo(RoutingInfo paramParentRoutingInfo, PolygoneNode paramOriginalEntryNode,PolygoneEdge paramRequestOriginalyStartedOnEdge,  PolygoneEdge paramLastRequestStartedOnEdge, PolygoneEdge paramRequestLastArrivedOnEdge, RoutingModeType paramRoutingMode, 
			NoRoutingActionType paramNoRoutingAction, int paramReboundHopsCount, int paramNodeHopsCount, PolygoneNode paramHyperNetEntryNode)
		{
			ParentRoutingInfo = paramParentRoutingInfo;
			OriginalEntryNode = paramOriginalEntryNode;
			RequestOriginalyStartedOnEdge = paramRequestOriginalyStartedOnEdge;
			RequestLastStartedOnEdge = paramLastRequestStartedOnEdge;
			RequestLastArrivedOnEdge = paramRequestLastArrivedOnEdge;
			RoutingMode = paramRoutingMode;
			NoRoutingAction = paramNoRoutingAction;
			ReboundHopsCount = paramReboundHopsCount;
			NodeHopsCount = paramNodeHopsCount;
			HyperNetEntryNode = paramHyperNetEntryNode;
		}
	}

	public class GeometricUtils
	{
		public static int PolygonicIncrement(int whichValue)
		{
			if (whichValue == 6)
				return 1;
			else
				return whichValue++;
		}

		public static int PolygonicDecrement(int whichValue)
		{
			if (whichValue == 1)
				return 6;
			else
				return whichValue--;
		}

		public static int[] GetOtherTwoFromTriSet(int whichIsThis)
		{
			int[] otherTwo = new int[2];
			otherTwo[0] = GetNextOfTri(whichIsThis);
			otherTwo[1] = GetNextOfTri(otherTwo[0]);
			return otherTwo;
		}

		public static int GetTheOtherFromTriSet(int notThisOne, int notThatOne)
		{
			int typeSum = notThisOne + notThatOne;
			switch (typeSum)
			{
				case 1: return 2; 
				case 3: return 0; 
				case 2: return 1; 
				default: throw new ArgumentException("GetTheOtherFromtriSet is passed points from which other can not be determined"); 
			}
		}


		public static int GetNextOfTri(int whichIsThis)
		{
			switch (whichIsThis)
			{
				case 0: return 1; 
				case 1: return 2; 
				case 2: return 0; 
				default: throw new ArgumentException("Invalid tri type");
			}
		}

		private static int _LastPolygoneID = 1;
		public static int GetNewPolygoneID()
		{
			return _LastPolygoneID++;
		}

		private static Random randomGenerator = null;
		public static int GetRandomNumber(int min, int max)
		{
			if (min != max)
			{
				if (min < max)
				{
					if (randomGenerator == null)
					{
						randomGenerator = new Random();
					}
					return randomGenerator.Next(min,max+1);
				}
				else
					return max;
			}
			else
			{
				return min;
			}
		}

		public static PolygoneEndType GetOppositeEndType(PolygoneEndType forWhichEndType)
		{
			switch(forWhichEndType)
			{
				case PolygoneEndType.N: return PolygoneEndType.S;
				case PolygoneEndType.S: return PolygoneEndType.N;
				case PolygoneEndType.NE: return PolygoneEndType.SW;
				case PolygoneEndType.NW: return PolygoneEndType.SE;
				case PolygoneEndType.SW: return PolygoneEndType.NE;
				case PolygoneEndType.SE: return PolygoneEndType.NW;
				case PolygoneEndType.Uninitialized: return PolygoneEndType.Uninitialized;
				default: throw new Exception("End type note recognized");
			}
		}

		public static PolygoneEndType GetLeftEndType(PolygoneEndType forWhichEndType)
		{
			switch(forWhichEndType)
			{
				case PolygoneEndType.N: return PolygoneEndType.SW;
				case PolygoneEndType.S: return PolygoneEndType.NE;
				case PolygoneEndType.NE: return PolygoneEndType.NW;
				case PolygoneEndType.NW: return PolygoneEndType.S;
				case PolygoneEndType.SW: return PolygoneEndType.SE;
				case PolygoneEndType.SE: return PolygoneEndType.N;
				case PolygoneEndType.Uninitialized: return PolygoneEndType.Uninitialized;
				default: throw new Exception("End type note recognized");
			}
		}

		public static PolygoneEndType GetRightEndType(PolygoneEndType forWhichEndType)
		{
			switch(forWhichEndType)
			{
				case PolygoneEndType.N: return PolygoneEndType.SE;
				case PolygoneEndType.S: return PolygoneEndType.NW;
				case PolygoneEndType.NE: return PolygoneEndType.S;
				case PolygoneEndType.NW: return PolygoneEndType.NE;
				case PolygoneEndType.SW: return PolygoneEndType.N;
				case PolygoneEndType.SE: return PolygoneEndType.SW;
				case PolygoneEndType.Uninitialized: return PolygoneEndType.Uninitialized;
				default: throw new Exception("End type note recognized");
			}
		}

		public static PolygoneEndType GetNextEndType(PolygoneEndType forWhichEndType)
		{
			switch(forWhichEndType)
			{
				case PolygoneEndType.N: return PolygoneEndType.NE;
				case PolygoneEndType.NE: return PolygoneEndType.SE;
				case PolygoneEndType.SE: return PolygoneEndType.S;
				case PolygoneEndType.S: return PolygoneEndType.SW;
				case PolygoneEndType.SW: return PolygoneEndType.NW;
				case PolygoneEndType.NW: return PolygoneEndType.N;
				case PolygoneEndType.Uninitialized: return PolygoneEndType.Uninitialized;
				default: throw new Exception("End type note recognized");
			}
		}

		public static PolygoneEndType GetPreviousEndType(PolygoneEndType forWhichEndType)
		{
			switch(forWhichEndType)
			{
				case PolygoneEndType.N: return PolygoneEndType.NW;
				case PolygoneEndType.NE: return PolygoneEndType.N;
				case PolygoneEndType.SE: return PolygoneEndType.NE;
				case PolygoneEndType.S: return PolygoneEndType.SE;
				case PolygoneEndType.SW: return PolygoneEndType.S;
				case PolygoneEndType.NW: return PolygoneEndType.SW;
				case PolygoneEndType.Uninitialized: return PolygoneEndType.Uninitialized;
				default: throw new Exception("End type note recognized");
			}
		}

		public static bool IsAdjescentEndTypes(PolygoneEndType endType1, PolygoneEndType endType2)
		{
			return (GetNextEndType(endType1)==endType2) || (GetPreviousEndType(endType1)==endType2);
		}

		public static PolygoneEndType[] GetToBeExcludedEndTypes(PolygoneEndType forWhichEndType)
		{
			PolygoneEndType[] toBeExcludedEndTypes = new PolygoneEndType[3];
			PolygoneEndType nextEndType = GetNextEndType(forWhichEndType);
			toBeExcludedEndTypes[0] = GetNextEndType(nextEndType);
			toBeExcludedEndTypes[1] = GetNextEndType(toBeExcludedEndTypes[0]);
			toBeExcludedEndTypes[2] = GetNextEndType(toBeExcludedEndTypes[1]);

			return toBeExcludedEndTypes;
		}

	}

}


