using System;
using System.Diagnostics;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Threading;

namespace Astrila.HiveNet
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.PictureBox mainRegionPictureBox;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Splitter splitter1;
		private System.Windows.Forms.NumericUpDown totalNodesUpDown;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.CheckBox disableAllPausesCheckBox;
		private System.Windows.Forms.CheckBox enableRefreshCheckBox;
		private System.Windows.Forms.CheckedListBox pausesCheckedListBox;
		private System.Windows.Forms.Button drawButton;
		private System.Windows.Forms.ProgressBar progressBar1;
		private System.Windows.Forms.Label currentNodeCountLabel;
		private System.Windows.Forms.Label timeLaspedLabel;
		private System.Windows.Forms.Button saveButton;
		private System.Windows.Forms.SaveFileDialog saveFileDialog1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.panel1 = new System.Windows.Forms.Panel();
			this.mainRegionPictureBox = new System.Windows.Forms.PictureBox();
			this.panel2 = new System.Windows.Forms.Panel();
			this.progressBar1 = new System.Windows.Forms.ProgressBar();
			this.drawButton = new System.Windows.Forms.Button();
			this.enableRefreshCheckBox = new System.Windows.Forms.CheckBox();
			this.disableAllPausesCheckBox = new System.Windows.Forms.CheckBox();
			this.pausesCheckedListBox = new System.Windows.Forms.CheckedListBox();
			this.label1 = new System.Windows.Forms.Label();
			this.totalNodesUpDown = new System.Windows.Forms.NumericUpDown();
			this.splitter1 = new System.Windows.Forms.Splitter();
			this.currentNodeCountLabel = new System.Windows.Forms.Label();
			this.timeLaspedLabel = new System.Windows.Forms.Label();
			this.saveButton = new System.Windows.Forms.Button();
			this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
			this.panel1.SuspendLayout();
			this.panel2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.totalNodesUpDown)).BeginInit();
			this.SuspendLayout();
			// 
			// panel1
			// 
			this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel1.Controls.Add(this.mainRegionPictureBox);
			this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel1.Location = new System.Drawing.Point(0, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(640, 469);
			this.panel1.TabIndex = 2;
			// 
			// mainRegionPictureBox
			// 
			this.mainRegionPictureBox.Dock = System.Windows.Forms.DockStyle.Fill;
			this.mainRegionPictureBox.Location = new System.Drawing.Point(0, 0);
			this.mainRegionPictureBox.Name = "mainRegionPictureBox";
			this.mainRegionPictureBox.Size = new System.Drawing.Size(638, 467);
			this.mainRegionPictureBox.TabIndex = 1;
			this.mainRegionPictureBox.TabStop = false;
			// 
			// panel2
			// 
			this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel2.Controls.Add(this.saveButton);
			this.panel2.Controls.Add(this.timeLaspedLabel);
			this.panel2.Controls.Add(this.currentNodeCountLabel);
			this.panel2.Controls.Add(this.progressBar1);
			this.panel2.Controls.Add(this.drawButton);
			this.panel2.Controls.Add(this.enableRefreshCheckBox);
			this.panel2.Controls.Add(this.disableAllPausesCheckBox);
			this.panel2.Controls.Add(this.pausesCheckedListBox);
			this.panel2.Controls.Add(this.label1);
			this.panel2.Controls.Add(this.totalNodesUpDown);
			this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
			this.panel2.Location = new System.Drawing.Point(0, 0);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(192, 469);
			this.panel2.TabIndex = 3;
			// 
			// progressBar1
			// 
			this.progressBar1.Location = new System.Drawing.Point(8, 256);
			this.progressBar1.Name = "progressBar1";
			this.progressBar1.Size = new System.Drawing.Size(176, 23);
			this.progressBar1.TabIndex = 7;
			// 
			// drawButton
			// 
			this.drawButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.drawButton.Location = new System.Drawing.Point(8, 216);
			this.drawButton.Name = "drawButton";
			this.drawButton.Size = new System.Drawing.Size(176, 23);
			this.drawButton.TabIndex = 6;
			this.drawButton.Text = "Start";
			this.drawButton.Click += new System.EventHandler(this.drawButton_Click);
			// 
			// enableRefreshCheckBox
			// 
			this.enableRefreshCheckBox.Location = new System.Drawing.Point(8, 176);
			this.enableRefreshCheckBox.Name = "enableRefreshCheckBox";
			this.enableRefreshCheckBox.Size = new System.Drawing.Size(168, 24);
			this.enableRefreshCheckBox.TabIndex = 5;
			this.enableRefreshCheckBox.Text = "Enable continuous refresh";
			this.enableRefreshCheckBox.CheckedChanged += new System.EventHandler(this.enableRefreshCheckBox_CheckedChanged);
			// 
			// disableAllPausesCheckBox
			// 
			this.disableAllPausesCheckBox.Location = new System.Drawing.Point(8, 64);
			this.disableAllPausesCheckBox.Name = "disableAllPausesCheckBox";
			this.disableAllPausesCheckBox.Size = new System.Drawing.Size(144, 24);
			this.disableAllPausesCheckBox.TabIndex = 4;
			this.disableAllPausesCheckBox.Text = "Disable all pauses";
			this.disableAllPausesCheckBox.CheckedChanged += new System.EventHandler(this.disableAllPausesCheckBox_CheckedChanged);
			// 
			// pausesCheckedListBox
			// 
			this.pausesCheckedListBox.Items.AddRange(new object[] {
																	  "Pause before connect request",
																	  "Pause after connect request",
																	  "Pause on connect",
																	  "Pause on polygone compl req"});
			this.pausesCheckedListBox.Location = new System.Drawing.Point(8, 88);
			this.pausesCheckedListBox.Name = "pausesCheckedListBox";
			this.pausesCheckedListBox.Size = new System.Drawing.Size(176, 79);
			this.pausesCheckedListBox.TabIndex = 3;
			this.pausesCheckedListBox.SelectedIndexChanged += new System.EventHandler(this.pausesCheckedListBox_SelectedIndexChanged);
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(8, 8);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(133, 16);
			this.label1.TabIndex = 2;
			this.label1.Text = "Total nodes in simulation:";
			// 
			// totalNodesUpDown
			// 
			this.totalNodesUpDown.Location = new System.Drawing.Point(8, 24);
			this.totalNodesUpDown.Maximum = new System.Decimal(new int[] {
																			 999999999,
																			 0,
																			 0,
																			 0});
			this.totalNodesUpDown.Minimum = new System.Decimal(new int[] {
																			 1,
																			 0,
																			 0,
																			 0});
			this.totalNodesUpDown.Name = "totalNodesUpDown";
			this.totalNodesUpDown.Size = new System.Drawing.Size(104, 20);
			this.totalNodesUpDown.TabIndex = 1;
			this.totalNodesUpDown.Value = new System.Decimal(new int[] {
																		   1000,
																		   0,
																		   0,
																		   0});
			this.totalNodesUpDown.ValueChanged += new System.EventHandler(this.totalNodesUpDown_ValueChanged);
			// 
			// splitter1
			// 
			this.splitter1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.splitter1.Location = new System.Drawing.Point(192, 0);
			this.splitter1.Name = "splitter1";
			this.splitter1.Size = new System.Drawing.Size(3, 469);
			this.splitter1.TabIndex = 4;
			this.splitter1.TabStop = false;
			// 
			// currentNodeCountLabel
			// 
			this.currentNodeCountLabel.AutoSize = true;
			this.currentNodeCountLabel.Location = new System.Drawing.Point(8, 280);
			this.currentNodeCountLabel.Name = "currentNodeCountLabel";
			this.currentNodeCountLabel.Size = new System.Drawing.Size(41, 16);
			this.currentNodeCountLabel.TabIndex = 8;
			this.currentNodeCountLabel.Text = "#nodes";
			// 
			// timeLaspedLabel
			// 
			this.timeLaspedLabel.AutoSize = true;
			this.timeLaspedLabel.Location = new System.Drawing.Point(8, 300);
			this.timeLaspedLabel.Name = "timeLaspedLabel";
			this.timeLaspedLabel.Size = new System.Drawing.Size(68, 16);
			this.timeLaspedLabel.TabIndex = 9;
			this.timeLaspedLabel.Text = "#time lasped";
			// 
			// saveButton
			// 
			this.saveButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.saveButton.Location = new System.Drawing.Point(8, 328);
			this.saveButton.Name = "saveButton";
			this.saveButton.Size = new System.Drawing.Size(176, 23);
			this.saveButton.TabIndex = 10;
			this.saveButton.Text = "Save Image";
			this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(640, 469);
			this.Controls.Add(this.splitter1);
			this.Controls.Add(this.panel2);
			this.Controls.Add(this.panel1);
			this.Name = "Form1";
			this.Text = "Form1";
			this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
			this.Load += new System.EventHandler(this.Form1_Load);
			this.panel1.ResumeLayout(false);
			this.panel2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.totalNodesUpDown)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			SimulationSettings.EnableRefresh=true;
			pausesCheckedListBox.SetItemChecked(0, SimulationSettings.EnablePauseBeforeConnectionRequested);
			pausesCheckedListBox.SetItemChecked(1, SimulationSettings.EnablePauseAfterConnectionRequested);
			pausesCheckedListBox.SetItemChecked(2, SimulationSettings.EnablePauseAfterConnected);
			pausesCheckedListBox.SetItemChecked(3, SimulationSettings.EnablePauseAfterPolygoneClosureRequested);
			disableAllPausesCheckBox.Checked = !SimulationSettings.EnablePauses;
			enableRefreshCheckBox.Checked = SimulationSettings.EnableRefresh;
			totalNodesUpDown.Value = SimulationSettings.TotalNodes;
		}

		private void SimulateNetwork()
		{
			GraphicPolygoneNode firstNode = new GraphicPolygoneNode(true);
			progressBar1.Maximum = SimulationSettings.TotalNodes;
			DateTime startTime = DateTime.Now;
			for (int i = 0; i < SimulationSettings.TotalNodes; i++)
			{
				GraphicPolygoneNode newNode = new GraphicPolygoneNode(false);				
				firstNode.RequestConnectToNetwork(newNode);
				if ((i%100==0) || SimulationSettings.EnableRefresh)
				{
					progressBar1.Value = i;
					currentNodeCountLabel.Text = i.ToString();
					timeLaspedLabel.Text = DateTime.Now.Subtract(startTime).Minutes.ToString() + ":" + DateTime.Now.Subtract(startTime).Seconds.ToString();
				}
			}
			RefreshImage();
		}

		private Thread _SimulationThread;
		private void StartDraw()
		{
			if (_SimulationThread != null) _SimulationThread.Abort() ;
			_SimulationThread = new Thread(new ThreadStart(SimulateNetwork));
			mainRegionPictureBox.Image = new Bitmap(mainRegionPictureBox.Width, mainRegionPictureBox.Height);
			Graphics mainRegionGraphics = Graphics.FromImage(mainRegionPictureBox.Image);

			SimulationSettings.NotifyRefreshDelegate rg = new  SimulationSettings.NotifyRefreshDelegate(this.RefreshImage);
			SimulationSettings.InitGraphics(mainRegionPictureBox.Width, mainRegionPictureBox.Height,mainRegionGraphics,rg);

			_SimulationThread.Priority = ThreadPriority.Highest;
			_SimulationThread.Start();
		}

		public void RefreshImage()
		{
			mainRegionPictureBox.Refresh();
		}

		private void UpdateSimulationSettingsFromUI()
		{
			SimulationSettings.TotalNodes = (int) totalNodesUpDown.Value;
			SimulationSettings.EnablePauseBeforeConnectionRequested = pausesCheckedListBox.GetItemChecked(0);
			SimulationSettings.EnablePauseAfterConnectionRequested = pausesCheckedListBox.GetItemChecked(1);
			SimulationSettings.EnablePauseAfterConnected = pausesCheckedListBox.GetItemChecked(2);
			SimulationSettings.EnablePauseAfterPolygoneClosureRequested = pausesCheckedListBox.GetItemChecked(3);
			SimulationSettings.EnablePauses = !disableAllPausesCheckBox.Checked;
			SimulationSettings.EnableRefresh = enableRefreshCheckBox.Checked;
		}

		private void totalNodesUpDown_ValueChanged(object sender, System.EventArgs e)
		{
			SimulationSettings.TotalNodes = (int) totalNodesUpDown.Value;
		}

		private void pausesCheckedListBox_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			SimulationSettings.EnablePauseBeforeConnectionRequested = pausesCheckedListBox.GetItemChecked(0);
			SimulationSettings.EnablePauseAfterConnectionRequested = pausesCheckedListBox.GetItemChecked(1);
			SimulationSettings.EnablePauseAfterConnected = pausesCheckedListBox.GetItemChecked(2);
			SimulationSettings.EnablePauseAfterPolygoneClosureRequested = pausesCheckedListBox.GetItemChecked(3);
		}

		private void disableAllPausesCheckBox_CheckedChanged(object sender, System.EventArgs e)
		{
			SimulationSettings.EnablePauses = !disableAllPausesCheckBox.Checked;
		}

		private void enableRefreshCheckBox_CheckedChanged(object sender, System.EventArgs e)
		{
			SimulationSettings.EnableRefresh = enableRefreshCheckBox.Checked;
		}

		private void drawButton_Click(object sender, System.EventArgs e)
		{
			UpdateSimulationSettingsFromUI();
			StartDraw();
		}

		private void saveButton_Click(object sender, System.EventArgs e)
		{
			if ((_SimulationThread != null)&&(_SimulationThread.IsAlive)) _SimulationThread.Suspend() ;
			if (saveFileDialog1.ShowDialog(this)==DialogResult.OK)
			{
				try
				{
					mainRegionPictureBox.Image.Save(saveFileDialog1.FileName);
				}
				catch(Exception ex)
				{
					MessageBox.Show(ex.ToString());
				}
			}
			if ((_SimulationThread != null)&&(_SimulationThread.IsAlive)) _SimulationThread.Resume() ;
		}
		

	}

	public class SimulationSettings
	{
		public delegate void NotifyRefreshDelegate();
		public static NotifyRefreshDelegate NotifyRefresh;
		public static int MaxX; 
		public static int MaxY;
		public static int StandardPenWidth = 3;
		
		private static int _PolygoneEdgeLength = 17;
		public static int PolygoneEdgeLength
		{
			get {return _PolygoneEdgeLength;}
			set
			{
				_PolygoneEdgeLength =(value >= 1)?value:1;
				PolygoneDiagonal1EdgeLength =_PolygoneEdgeLength  / ROOT2;
				PolygoneDiagonal2EdgeLength = (_PolygoneEdgeLength*0.75) / ROOT2;
			}
		}

		private static double _PolygoneDiagonal1EdgeLength = PolygoneEdgeLength / ROOT2;
		public static double PolygoneDiagonal1EdgeLength
		{
			get {return _PolygoneDiagonal1EdgeLength;}
			set
			{
				_PolygoneDiagonal1EdgeLength =(value >= 1)?value:1;
			}
		}

		private static double _PolygoneDiagonal2EdgeLength = (PolygoneEdgeLength*0.75) / ROOT2;
		public static double PolygoneDiagonal2EdgeLength
		{
			get {return _PolygoneDiagonal2EdgeLength;}
			set
			{
				_PolygoneDiagonal2EdgeLength =(value >= 1)?value:1;
			}
		}

		public static Pen StandardPointPen = new Pen(Brushes.Black, StandardPenWidth);
		public static Pen ConnectionRequestedPointPen = new Pen(Brushes.Red, StandardPenWidth);
		public static Pen PolygoneClosureRequestedPointPen = new Pen(Brushes.Yellow, StandardPenWidth);
		public static Pen ConnmectedNormallyPointPen = new Pen(Brushes.RoyalBlue, StandardPenWidth);
		public static Brush HyperNodeBrush = Brushes.Fuchsia;
		
		private static int _TotalNodes = 1000;
		public static int TotalNodes
		{
			get {return _TotalNodes;}
			set
			{
				_TotalNodes = value;
				PolygoneEdgeLength =(int)((31/Math.Sqrt(_TotalNodes)) * 20);
			}
		}

		public static int PauseBeforeConnectionRequested = 1000;
		public static int PauseAfterConnectionRequested = 1000;
		public static int PauseAfterPolygoneClosureRequested = 500;
		public static int PauseAfterConnected = 500;

		private static bool _EnablePauseBeforeConnectionRequested = false;
		public static bool EnablePauseBeforeConnectionRequested
		{
			get { return _EnablePauseBeforeConnectionRequested && EnablePauses;}
			set { _EnablePauseBeforeConnectionRequested = value; }
		}

		private static bool _EnablePauseAfterConnectionRequested = false;
		public static bool EnablePauseAfterConnectionRequested
		{
			get { return _EnablePauseAfterConnectionRequested && EnablePauses;}
			set { _EnablePauseAfterConnectionRequested = value; }
		}

		private static bool _EnablePauseAfterPolygoneClosureRequested = false;
		public static bool EnablePauseAfterPolygoneClosureRequested
		{
			get { return _EnablePauseAfterPolygoneClosureRequested && EnablePauses;}
			set { _EnablePauseAfterPolygoneClosureRequested = value; }
		}

		private static bool _EnablePauseAfterConnected = false;
		public static bool EnablePauseAfterConnected
		{
			get { return _EnablePauseAfterConnected && EnablePauses;}
			set { _EnablePauseAfterConnected = value; }
		}

		private static bool _EnablePauses = false;
		public static bool EnablePauses
		{
			get { return _EnablePauses && !FastestDrawing;}
			set { _EnablePauses = value; }
		}

		private static bool _EnableRefresh = false;
		public static bool EnableRefresh
		{
			get { return _EnableRefresh && !FastestDrawing;}
			set { _EnableRefresh = value; }
		}

		public static bool FastestDrawing = false;

		public static Pen[] PolygoneLinePens = new Pen[] {new Pen(Color.RosyBrown,1), new Pen(Color.YellowGreen,1), new Pen(Color.Turquoise,1), 
													   new Pen(Color.SeaGreen,1), new Pen(Color.Teal ,1), new Pen(Color.BlueViolet,1)};

		public const double ROOT2 = 1.4142135623730950488016887242097;
		public static Graphics DrawingBoard = null;

		public static void RefreshDrawingBoard()
		{
			if (EnableRefresh)
				NotifyRefresh();
		}

		public static void InitGraphics(int paramMaxX, int paramMinY, Graphics paramDrawingBoard, NotifyRefreshDelegate paramNotifyRefresh)
		{
			MaxX = paramMaxX;
			MaxY = paramMinY;
			DrawingBoard = paramDrawingBoard;
			DrawingBoard = paramDrawingBoard;
			NotifyRefresh = paramNotifyRefresh;
		}

		public static Pen[] PensForHyperDepths = new Pen[] {ConnmectedNormallyPointPen, 
			new Pen(Brushes.Fuchsia, StandardPenWidth+1), new Pen(Brushes.Goldenrod, StandardPenWidth+1), new Pen(Brushes.FloralWhite, StandardPenWidth+1)};
		public static Pen PenForSuperHyperDepth = new Pen(Brushes.DimGray, StandardPenWidth+1);
		public static Pen FirstNodePen = new Pen(Brushes.Aqua, StandardPenWidth+2);
	}

	
	public class GraphicPolygoneNode : PolygoneNode
	{
		private PointF _MyDrawingPoint = PointF.Empty;
		public GraphicPolygoneNode(bool isFirstPoint)
		{
			if (isFirstPoint)
			{
				_MyDrawingPoint = new Point(SimulationSettings.MaxX/2, SimulationSettings.MaxY/2);
				Draw(SimulationSettings.FirstNodePen);
			}
		}

		private void Draw(Pen penToUse)
		{
			Debug.Assert(!_MyDrawingPoint.Equals(PointF.Empty), "Can't draw pixel because its empty");

			SimulationSettings.DrawingBoard.DrawEllipse(penToUse, _MyDrawingPoint.X,  _MyDrawingPoint.Y, 1,  1);
		}

		protected override void OnBeforeConnectToIncomingNode(PolygoneNode incomingNode, RoutingInfo paramRoutingInfo)
		{
			if (SimulationSettings.EnableRefresh)
			{
				Draw((paramRoutingInfo.RoutingMode==RoutingModeType.ConnectOrRoute)?SimulationSettings.ConnectionRequestedPointPen:SimulationSettings.PolygoneClosureRequestedPointPen);		
				SimulationSettings.RefreshDrawingBoard() ;
			}
			if (SimulationSettings.EnablePauseBeforeConnectionRequested)
			{
				System.Threading.Thread.Sleep((paramRoutingInfo.RoutingMode==RoutingModeType.ConnectOrRoute)?SimulationSettings.PauseBeforeConnectionRequested:SimulationSettings.PauseAfterPolygoneClosureRequested);
			}
		}

		protected override void OnHyperNodeParticipationChange()
		{
			DrawConnectedNode();
		}


		protected override void OnAfterConnectToIncomingNode(PolygoneNode incomingNode, RoutingInfo paramRoutingInfo)
		{
			if (SimulationSettings.EnableRefresh)
			{
				Draw(SimulationSettings.ConnmectedNormallyPointPen);
				SimulationSettings.RefreshDrawingBoard() ;
			}
			if (SimulationSettings.EnablePauseAfterConnectionRequested)
			{
				System.Threading.Thread.Sleep(SimulationSettings.PauseAfterConnectionRequested);
			}
		}

		protected override void OnConnectionCompleted(PolygoneNode otherNode, PolygoneEdge otherNodeEdge, PolygoneEdge myEdge)
		{
			//Calculate my point
			PointF sourcePoint = ((GraphicPolygoneNode) otherNode)._MyDrawingPoint;
			switch(otherNodeEdge.EndType)
			{
				case PolygoneEndType.N:
					_MyDrawingPoint.X = sourcePoint.X;
					_MyDrawingPoint.Y = sourcePoint.Y + SimulationSettings.PolygoneEdgeLength*0.75f;
					break;
				case PolygoneEndType.S:
					_MyDrawingPoint.X = sourcePoint.X;
					_MyDrawingPoint.Y = sourcePoint.Y - SimulationSettings.PolygoneEdgeLength*0.75f;
					break;
				case PolygoneEndType.NE:
					_MyDrawingPoint.X =  (float) (sourcePoint.X + SimulationSettings.PolygoneDiagonal1EdgeLength);
					_MyDrawingPoint.Y = (float) (sourcePoint.Y + SimulationSettings.PolygoneDiagonal2EdgeLength);
					break;
				case PolygoneEndType.NW:
					_MyDrawingPoint.X = (float) (sourcePoint.X - SimulationSettings.PolygoneDiagonal1EdgeLength);
					_MyDrawingPoint.Y = (float) (sourcePoint.Y + SimulationSettings.PolygoneDiagonal2EdgeLength);
					break;
				case PolygoneEndType.SE:
					_MyDrawingPoint.X = (float) (sourcePoint.X + SimulationSettings.PolygoneDiagonal1EdgeLength);
					_MyDrawingPoint.Y = (float) (sourcePoint.Y - SimulationSettings.PolygoneDiagonal2EdgeLength);
					break;
				case PolygoneEndType.SW:
					_MyDrawingPoint.X = (float) (sourcePoint.X - SimulationSettings.PolygoneDiagonal1EdgeLength);
					_MyDrawingPoint.Y = (float) (sourcePoint.Y - SimulationSettings.PolygoneDiagonal2EdgeLength);
					break;
				default:
					throw new Exception("edge End type not recognized");
			}

			DrawConnectedNode();

			SimulationSettings.DrawingBoard.DrawLine(SimulationSettings.PolygoneLinePens[(int) otherNodeEdge.EndType],sourcePoint,_MyDrawingPoint);
			SimulationSettings.RefreshDrawingBoard() ;
			if (SimulationSettings.EnablePauseAfterConnected)
			{
				System.Threading.Thread.Sleep(SimulationSettings.PauseAfterConnected);
			}
		}

		private void DrawConnectedNode()
		{
			int depth = GetHyperNetHeight();
			if (depth < SimulationSettings.PensForHyperDepths.Length)
				Draw(SimulationSettings.PensForHyperDepths[depth]);
			else
				Draw(SimulationSettings.PenForSuperHyperDepth);
		}


	}
}
