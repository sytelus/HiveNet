<map version="0.7.1">
<node TEXT="HiveNet Algos">
<node TEXT="Dynamic Network Formation" POSITION="right">
<node TEXT="Random Edge Finding">
<node TEXT="Basic random edge finding">
<icon BUILTIN="button_ok"/>
</node>
<node TEXT="Fast Random edge finding"/>
</node>
<node TEXT="Basic" FOLDED="true">
<icon BUILTIN="button_ok"/>
<node TEXT="Prevent mal-polygone formation"/>
<node TEXT="Any node can only connect to other 3 nodes"/>
<node TEXT="Symmitric network formation at any time"/>
<node TEXT="Any open point must be used"/>
<node TEXT="non-greedy polygones - new point need not travel around polygone"/>
</node>
<node TEXT="Closing polygone ends"/>
<node TEXT="Routing around a polygone"/>
<node TEXT="Suiciddal Disconnect"/>
<node TEXT="Node Removal Implementation"/>
<node TEXT="review: operations in network with holes"/>
<node TEXT="review: network latency effects"/>
<node TEXT="review: malicious clients impact"/>
<node TEXT="Convert to N-polygone algos"/>
<node TEXT="higher dimentional networks"/>
<node TEXT="stiching fragments implementation"/>
</node>
<node TEXT="Requirements" FOLDED="true" POSITION="right">
<node TEXT="Should form symmystric net (circular edge)"/>
<node TEXT="Any node as entry point"/>
<node TEXT="Should enable routing even with holes in the route"/>
<node TEXT="Stichable fragments"/>
<node TEXT="Exit without causing network traffic"/>
<node TEXT="Handle 1/3 of malicious nodes"/>
<node TEXT="Prevent mal-polygone formations"/>
<node TEXT="Enable secure messaging"/>
<node TEXT="Survive network latecies/lazy clients"/>
<node TEXT="everybody knows code, several implementations with potentially different versions of algorithms"/>
</node>
<node TEXT="Reasons for Hexagones" FOLDED="true" POSITION="left">
<node TEXT="3 edges means 25% less re-distribution load on each client than mesh"/>
<node TEXT="On disconnect only 3 points gets disconnected instead of 4"/>
<node TEXT="For evey private graph you need extra N points. For 3 private graphs, savings is 3 connections."/>
<node TEXT="Every router node needs to maintain N extra connections"/>
<node TEXT="NATs UDP hole punching limits numbers of new connections that can be made"/>
</node>
<node TEXT="Measurements" FOLDED="true" POSITION="left">
<node TEXT="Average network traffic caused by each new connection"/>
<node TEXT="Average network traffic caused by each disconnection"/>
<node TEXT="Average trafic caused by each random edge finding"/>
</node>
<node TEXT="Searching" FOLDED="true" POSITION="right">
<node TEXT="Node searching/presence"/>
<node TEXT="resource searching"/>
</node>
<node TEXT="Broadcasting" FOLDED="true" POSITION="right">
<node TEXT="continuous data stream"/>
<node TEXT="sporadic data bursts"/>
<node TEXT="Private groups"/>
<node TEXT="Diff broadcasts"/>
<node TEXT="Event braodcating (say distributed code finished some task)"/>
</node>
<node TEXT="Security" FOLDED="true" POSITION="left">
<node TEXT="Node Identity protection"/>
<node TEXT="group membership protection"/>
<node TEXT="Group resource protection"/>
</node>
<node TEXT="Others" FOLDED="true" POSITION="right">
<node TEXT="Network events"/>
<node TEXT="Network topology query APIs"/>
<node TEXT="Distributed code"/>
</node>
</node>
</map>
